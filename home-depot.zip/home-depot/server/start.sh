# Seed the database
node init_db.js

# Start the server
node index.js